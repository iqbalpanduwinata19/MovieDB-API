class MovieItem extends HTMLElement {

    constructor() {
        super();
        this.shadowDOM = this.attachShadow({ mode: 'open' });
    }

    set movie(movie) {
        this._movie = movie;
        this.render();
    }

    render() {
        const img_url = 'https://image.tmdb.org/t/p/w500';
        const { title, release_date, poster_path, vote_average, overview } = this._movie;
        this.shadowDOM.innerHTML = `
        <style>.movie {
            width: 300px;
            margin: 1rem;
            border-radius: 3px;
            box-shadow: 0.1px 4px 5px rgb(0, 0, 0, 0.2);
            background-color: var(--secondary-color);
            position: relative;
            overflow: hidden;
            border-radius: 3px;
        }
        
        .movie img {
            width: 100%;
        }
        
        .movie-info {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem 0.5rem 0.5rem;
            letter-spacing: 0.5px;
        }
        
        .movie-info h3 {
            margin-top: 0;
        }
        
        .movie-info span {
            color: black;
            font-size: small;
            font-weight: bold;
            background-color: yellow;
            padding: 0.2rem 0.5rem;
            border-radius: 5px;
        }
        
        .plot {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: peru;
            padding: 1rem;
            max-height: 100%;
            transform: translateY(101%);
            transition: transform 0.5s ease-in;
        }
        
        .movie:hover .plot {
            transform: translateY(0)
        }</style>
        <div class="movie">
        
        <img src="${img_url + poster_path}" alt="${title}">
        <div class="movie-info">
            <h3>${title} (${release_date})</h3>
            <span>${vote_average}</span>
       
        </div>
        <div class="plot">
       
            <h3>Plot</h3>
             ${overview}
        </div>
        </div>
      `;
    }
}

customElements.define('movie-item', MovieItem);
