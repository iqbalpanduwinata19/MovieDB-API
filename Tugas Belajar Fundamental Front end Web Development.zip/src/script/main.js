import '../styles/style.css'
import './component/movie-item.js';


const API_KEY = 'api_key=5d235d01bdba53fc68025ef8fe23f226';
const base_url = 'https://api.themoviedb.org/3';
const api_url = `${base_url}/discover/movie?sort_by=popularity.desc&${API_KEY}`;


const main = document.getElementById('main');



const getMovies = url => {
    fetch(url).then(Response => Response.json()).then(data => {
        showMovies(data.results);
    })

};

const showMovies = data => {
    main.innerHTML = '';

    data.forEach(movie => {

        const movieElement = document.createElement('movie-item')
        movieElement.movie = movie;

        main.appendChild(movieElement);
    })
}

document.addEventListener('DOMContentLoaded', () => {
    getMovies(api_url);
});